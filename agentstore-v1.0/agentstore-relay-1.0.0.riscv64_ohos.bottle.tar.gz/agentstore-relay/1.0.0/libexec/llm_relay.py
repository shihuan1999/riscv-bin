# -*- coding: UTF-8 -*-
"""agentstore-relay -- PC/device-side LLM relay for the AgentStore HAP.

Device HAP defaults to http://127.0.0.1:16000/v1 (hdc rport USB tunnel).
This relay forwards OpenAI-compatible requests to the upstream endpoint and
injects the API key, so the key never lands on the device.

Config via env:
  RELAY_PORT     listen port          (default 16000)
  RELAY_UPSTREAM upstream base URL    (default https://api.rvcompute.com:60000)
  RELAY_API_KEY  Bearer key           (REQUIRED -- not bundled)

Usage (PC):  hdc rport tcp:16000 tcp:16000
             RELAY_API_KEY=sk-xxx agentstore-relay
"""
import http.server
import json
import os
import socketserver
import sys
import urllib.error
import urllib.request

UPSTREAM = os.environ.get('RELAY_UPSTREAM', 'https://api.rvcompute.com:60000')
API_KEY = os.environ.get('RELAY_API_KEY', '')
PORT = int(os.environ.get('RELAY_PORT', '16000'))

if not API_KEY:
    print('agentstore-relay: RELAY_API_KEY is required (key stays on this host, never on the device)')
    sys.exit(1)


class Relay(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def _relay(self):
        length = int(self.headers.get('Content-Length') or 0)
        body = self.rfile.read(length) if length else None
        url = UPSTREAM + self.path
        req = urllib.request.Request(url, data=body, method=self.command)
        for h in ('Content-Type', 'Accept'):
            if self.headers.get(h):
                req.add_header(h, self.headers[h])
        req.add_header('Authorization', 'Bearer ' + API_KEY)
        try:
            with urllib.request.urlopen(req, timeout=600) as resp:
                data = resp.read()
                self.send_response(resp.status)
                ct = resp.headers.get('Content-Type', 'application/json')
                self.send_header('Content-Type', ct)
                self.send_header('Content-Length', str(len(data)))
                self.end_headers()
                self.wfile.write(data)
        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            ct = e.headers.get('Content-Type', 'application/json') if e.headers else 'application/json'
            self.send_header('Content-Type', ct)
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            msg = json.dumps({'error': {'message': str(e)}}).encode()
            self.send_response(502)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(msg)))
            self.end_headers()
            self.wfile.write(msg)

    do_GET = _relay
    do_POST = _relay

    def log_message(self, fmt, *args):
        sys.stderr.write('[agentstore-relay] ' + fmt % args + '\n')


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


if __name__ == '__main__':
    print('agentstore-relay: ' + UPSTREAM + ' -> 127.0.0.1:' + str(PORT) +
          ' (device: hdc rport tcp:' + str(PORT) + ' tcp:' + str(PORT) + ')')
    Server(('127.0.0.1', PORT), Relay).serve_forever()
