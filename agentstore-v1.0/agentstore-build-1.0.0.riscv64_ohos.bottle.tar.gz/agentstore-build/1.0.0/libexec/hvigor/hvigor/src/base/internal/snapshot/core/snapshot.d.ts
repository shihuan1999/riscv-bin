export declare class Snapshot {
}
